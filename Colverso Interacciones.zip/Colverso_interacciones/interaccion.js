let slideIndex = 1;
showSlides(slideIndex);

function plusSlides(n) {
    showSlides(slideIndex += n);
}

function currentSlide(n) {
    showSlides(slideIndex = n);
}

function showSlides(n) {
    let i;
    let slides = document.getElementsByClassName("mySlides");
    let dots = document.getElementsByClassName("dot");
    if (n > slides.length) { slideIndex = 1 }
    if (n < 1) { slideIndex = slides.length }
    for (i = 0; i < slides.length; i++) {
        slides[i].style.display = "none";
    }
    for (i = 0; i < dots.length; i++) {
        dots[i].className = dots[i].className.replace(" active", "");
    }
    slides[slideIndex - 1].style.display = "block";
    dots[slideIndex - 1].className += " active";
}

/*Interaccion con el pj*/

const imagen = document.getElementById('imagen');
const textoFlotante = document.getElementById('texto-flotante');

imagen.addEventListener('click', () => {
  textoFlotante.classList.toggle('mostrar');
});

/*Interaccion con el pj2*/

const imagen2 = document.getElementById('imagen2');
const textoFlotante2 = document.getElementById('texto-flotante2');

imagen2.addEventListener('click', () => {
    textoFlotante2.classList.toggle('mostrar');
})

/*Interaccion con el pj3*/

const imagen3 = document.getElementById('imagen3');
const textoFlotante3 = document.getElementById('texto-flotante3');

imagen3.addEventListener('click', () => {
    textoFlotante3.classList.toggle('mostrar');
})

/*Interaccion con el carro*/

var movimiento = document.querySelector('.car_img')

movimiento.addEventListener('click', animations)

function animations() {
    movimiento.classList.toggle('car_animation')
}

/*Interaccion con el boton*/

const boton = document.getElementById('btn_1');
const textoFlotante4 = document.getElementById('texto-flotante4');

boton.addEventListener('click', () => {
    textoFlotante4.classList.toggle('mostrar')
})


/*interaccion tlf*/

let display = document.querySelector('.display');

function appendToDisplay(value) {
  display.value += value;
}

function clearDisplay() {
  display.value = '';
}

function calculate() {
    try {
      let result = eval(display.value);
      if (result === 1903) {
        display.value = result;
        window.alert('Correcto')
      } else {
        display.value = 'Error';
      }
    } catch (error) {
      display.value = 'Error';
    }
  }